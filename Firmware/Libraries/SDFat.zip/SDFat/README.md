## SdFat Library for Inkplate 6

**Please note: this library is now implemented in Inkplate 6 Arduino library and it is not required to be installed.**

Originally made by Bill Greiman, edited by e-radionica.com to work with Inkplate 6

Install this library if you want to use Inkplate 6 SD card funcionality.


Learn more about Inkplate: www.inkplate.io

Inkplate 6 Arduino library: https://github.com/e-radionicacom/Inkplate-6-Arduino-library

Inkplate 6 Hardware design: https://github.com/e-radionicacom/Inkplate-6-hardware
